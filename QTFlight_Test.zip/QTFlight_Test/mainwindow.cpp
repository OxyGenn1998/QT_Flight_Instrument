#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , timerId(0)
{
    ui->setupUi(this);
    timerId=startTimer(50);
}

MainWindow::~MainWindow()
{
    killTimer(timerId);
    delete ui;
}

void MainWindow::timerEvent(QTimerEvent *event)
{
    QMainWindow::timerEvent(event);
    ui->graphicsEADI->redraw();
    ui->graphicsASI->redraw();
}

void MainWindow::on_doubleSpinBoxPitch_valueChanged(double arg1)
{
    ui->graphicsEADI->setPitch(arg1);
    //ui->graphicsEADI->redraw();
}


void MainWindow::on_doubleSpinBoxRoll_valueChanged(double arg1)
{
    ui->graphicsEADI->setRoll(arg1);
   // ui->graphicsEADI->redraw();
}


void MainWindow::on_horizontalScrollBar_valueChanged(int value)
{
    ui->graphicsASI->setAirspeed(value);
    ui->graphicsEADI->setAirspeed(value);

}

